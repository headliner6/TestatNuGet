﻿using System.Windows.Controls;

namespace TestatNuGet.View
{
    public partial class LogMessageAddView : UserControl
    {
        public LogMessageAddView()
        {
            InitializeComponent();
        }
    }
}
