﻿using System.Windows.Controls;

namespace TestatNuGet.View
{
    public partial class LogentriesView : UserControl
    {
        public LogentriesView()
        {
            InitializeComponent();
        }
    }
}
